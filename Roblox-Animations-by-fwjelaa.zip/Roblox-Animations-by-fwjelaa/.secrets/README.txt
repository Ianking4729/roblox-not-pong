Optional. Put your Roblox Open Cloud API key in a file called roblox-api-key.txt in this folder (just the key,
nothing else) if you want kit/upload.py to publish animations for you.
NEVER share this folder, commit it, show it on stream or put it in a zip. Anyone with the key can upload to your
account. See "Automatic upload" in GUIDE.md.
